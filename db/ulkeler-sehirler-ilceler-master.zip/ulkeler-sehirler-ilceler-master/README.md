# Ülkeler, Şehirler ve İlçeler Veritabanı listesi
Ülkeler, Şehirler ve İlçeler Veritabanı listesi yabancı kaynaktan alıp Türkiye illeri ve ilçeleri revize edilmiştir.
